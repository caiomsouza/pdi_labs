# Pentaho Data Services Demo Lab 

This lab was created to test Pentaho Data Services feature.

# Reference

Use Pentaho Data Services<BR>
https://help.pentaho.com/Documentation/7.0/0L0/0Y0/090<BR>

Connect to a Pentaho Data Service<BR>
https://help.pentaho.com/Documentation/7.0/0L0/0Y0/090/040<BR>

Develop and Optimize a Pentaho Data Service<BR>
https://help.pentaho.com/Documentation/7.0/0L0/0Y0/090/020<BR>

PDI JDBC Data Services: Accessing Blended & Transformed Data with JDBC Regardless of Source<BR>
https://www.youtube.com/watch?v=SZRMe9Em25o<BR>

# Important
Pentaho Data Services will only work if you are connected with PDI Repository.

# Env
Samples were created using PDI 7.0 EE
